# Resin Keycap – Netlify Deploy (Hidden/Staging)
This bundle blocks search engines while you test.

## Files
- `index.html` – includes `<meta name="robots" content="noindex, nofollow">`
- `robots.txt` – `Disallow: /`

## Netlify settings
- Branch to deploy: `main`
- Build command: *(leave empty)*
- Publish directory: `.`

## When ready to go public
- Remove the `<meta name="robots" ...>` line in `index.html`
- Replace `robots.txt` content with:
```
User-agent: *
Allow: /
```
- Commit and Netlify will redeploy.
